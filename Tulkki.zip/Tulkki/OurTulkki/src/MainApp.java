
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.antlr.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.tree.ParseTree;

import AST.ASTNode;
import AST.OurASTVisitor;
import AST.Type;
import OurLanguage.OurLanguageBaseVisitor;
import OurLanguage.OurLanguageLexer;
import OurLanguage.OurLanguageParser;
import OurLanguage.OurLanguageParser.ProgramContext;
import OurLanguage.OurLanguageParser.ValueContext;
import OurLanguage.OurLanguageVisitor;
 
public class MainApp 
{
    @SuppressWarnings("deprecation")
	public static void main( String[] args )
    {
    	String input = "C:\\MyTemp\\KaTe\\Testit\\variableTest.txt";
        try {
    	CharStream charstream =
    			CharStreams.fromFileName(input);
		
    	//"C:\\MyTemp\\KaTe\\inputOutputTest1.txt"
    	
        OurLanguageLexer lexer = new OurLanguageLexer(charstream);
        CommonTokenStream commonTokenStream = new CommonTokenStream(lexer);
        OurLanguageParser parser = new OurLanguageParser(commonTokenStream);
        //ProgramContext prc = parser.program();
        ParseTree tree = parser.program();
        //OurLanguageBaseVisitor visitor = new OurLanguageBaseVisitor();
        OurASTVisitor visitor = new OurASTVisitor();
        ASTNode ast = visitor.visit(tree);
        Map<String, Type> tenv = new HashMap<String, Type>();
        ast.typeCheck(tenv);
        System.out.println(ast);
        System.out.println(tenv);
        
        /*OurLanguageParser.FileContext fileContext = parser.file();                
        MarkupVisitor visitor = new MarkupVisitor();                
        visitor.visit(fileContext);*/
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}