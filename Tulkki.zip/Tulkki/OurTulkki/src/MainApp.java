
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;

import AST.ASTNode;
import AST.OurASTVisitor;
import AST.Program;
import AST.Type;
import OurLanguage.OurLanguageLexer;
import OurLanguage.OurLanguageParser;
import Module.LocalVar;
import Module.Module;
import Module.WATGen;
 
public class MainApp 
{
	public static void main( String[] args )
    {
    	String input = "C:\\MyTemp\\KaTe\\Testit\\" + args[0] + ".txt";
    	
    	String[] args2 = Arrays.copyOfRange(args, 1, args.length);
    	System.out.println(args2);
    	
        try {
    	CharStream charstream =
    			CharStreams.fromFileName(input);
		
    	//"C:\\MyTemp\\KaTe\\inputOutputTest1.txt"
    	
        OurLanguageLexer lexer = new OurLanguageLexer(charstream);
        CommonTokenStream commonTokenStream = new CommonTokenStream(lexer);
        OurLanguageParser parser = new OurLanguageParser(commonTokenStream);
        //ProgramContext prc = parser.program();
        ParseTree tree = parser.program();
        //OurLanguageBaseVisitor visitor = new OurLanguageBaseVisitor();
        OurASTVisitor visitor = new OurASTVisitor();
        ASTNode ast = visitor.visit(tree);
        Map<String, Type> tenv = new HashMap<String, Type>();
        ast.typeCheck(tenv);
        System.out.println(ast);
        System.out.println(tenv);
        Program prog = (Program) ast;
        Map<String, Number> env = new HashMap<String, Number>();
        System.out.println(prog.run(env, args2));
        
        Module mod = new Module();
        
        Map<String, LocalVar> genv = new HashMap<String, LocalVar>();
        ast.generate(mod, genv);
        System.out.println(mod);
        ArrayList<String> list = mod.listing();
        System.out.println(list.size());
        
        for (String str : list)
        {
        	System.out.println(str);
        	
        }
        
        Number output = mod.run(args2);
        System.out.println(output);
        if (output != null)
        {
        if (!output.equals(prog.run(env, args2)))
        	System.out.println("Test run failed");
        }
        else
        {
        	if (prog.run(env, args2) != null)
        	{
        		System.out.println("Test run failed; both should be null");
        	}
        }
        
        String wat = mod.watgen();
        System.out.println(wat);
        
        /*OurLanguageParser.FileContext fileContext = parser.file();                
        MarkupVisitor visitor = new MarkupVisitor();                
        visitor.visit(fileContext);*/
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}