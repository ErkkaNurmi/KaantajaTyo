package AST;

import java.util.Map;

public class Var extends Value
{
	String id;
	
	public Var(String _id)
	{
		id = _id;
	}
	
	@Override
	public boolean canAssign(Type t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		if (tenv.containsKey(id)) type = tenv.get(id);
		else ;//virheilmoitus
	}

}
