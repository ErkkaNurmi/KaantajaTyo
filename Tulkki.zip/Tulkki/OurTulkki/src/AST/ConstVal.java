package AST;

import java.util.Map;

public class ConstVal extends Value
{
	String value;
	
	public ConstVal(String _value, Type t)
	{
		type = t;
		value = _value;
	}
	
	@Override
	public boolean canAssign(Type t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		//Ei tee mit��n
	}

}
