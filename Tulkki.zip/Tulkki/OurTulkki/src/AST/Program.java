package AST;

import java.util.Map;

public class Program extends ASTNode
{
	String name;
	VarDeclarations params;
	public ASTNode body;

	public Program(String _name, VarDeclarations visitedParamList, ASTNode _body)
	{
		name = _name;
		params = visitedParamList;
		body = _body;
	}

	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		for (VarDeclaration v : params.vars)
		{
			v.declare(tenv);
		}
		body.typeCheck(tenv);
	}
}
