package AST;

public class Mul extends Arithmetic
{

	public Mul(Value l, Value r) {
		super(l, r);
		// TODO Auto-generated constructor stub
	}

}
