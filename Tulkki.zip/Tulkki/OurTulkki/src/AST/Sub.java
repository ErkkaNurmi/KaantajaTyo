package AST;

public class Sub extends Arithmetic
{

	public Sub(Value l, Value r) {
		super(l, r);
		// TODO Auto-generated constructor stub
	}
}
