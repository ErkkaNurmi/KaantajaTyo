package AST;

public class Add extends Arithmetic
{

	public Add(Value l, Value r) {
		super(l, r);
		// TODO Auto-generated constructor stub
	}

}
