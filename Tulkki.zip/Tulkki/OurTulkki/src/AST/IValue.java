package AST;

public abstract class IValue extends ASTNode
{
	public Type type = null;
	
	public boolean isInt()
	{
		if (type == null) return false;
		return type.isInt();
	}
	public boolean isDouble()
	{
		if (type == null) return false;
		return type.isDouble();
	}
	public boolean isBool()
	{
		if (type == null) return false;
		return type.isBool();
	}
	public abstract boolean canAssign(Type t);
	
}
