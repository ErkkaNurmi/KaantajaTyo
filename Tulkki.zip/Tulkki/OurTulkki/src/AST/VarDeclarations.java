package AST;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class VarDeclarations extends ASTNode 
{
	List<VarDeclaration> vars = new ArrayList<VarDeclaration>();
	
	public VarDeclarations(List<VarDeclaration> _vars)
	{
		vars = _vars;
	}
	
	@Override
	public void typeCheck(Map<String, Type> tenv) {
		// TODO Auto-generated method stub
		
	}

}
