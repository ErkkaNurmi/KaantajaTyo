package AST;

import java.util.Map;

public class Arithmetic	extends Value
{
	Value left;
	Value right;
	
	public Arithmetic(Value l, Value r)
	{
		left = l;
		right = r;
	}
	
	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		left.typeCheck(tenv);
		right.typeCheck(tenv);
		Type leftType = left.type;
		Type rightType = right.type;
		if (leftType.isInt())
		{
			if (rightType.isInt())
			{
				type = rightType;
			}
			else if (rightType.isDouble())
			{
				type = rightType;
			}
		}
		else if (leftType.isDouble())
		{
			type = leftType;
		}
		else
		{
			//T�h�n virheilmoitus
		}
	}
}
