package AST;

import java.util.Map;

public class ForStatement extends ASTNode
{
	Type loop;
	ASTNode body;

	public ForStatement(Type _loop, ASTNode _body)
	{
		loop = _loop;
		body = _body;
	}
	
	@Override
	public void typeCheck(Map tenv)
	{
		if (!loop.isInt())
		{
			//virheilmoitus
		}
		body.typeCheck(tenv);
	}

}
