package AST;

import java.util.Map;

public class Value extends ASTNode
{

	public boolean canAssign(Type t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		type.typeCheck(tenv);
	}

}
