package AST;

import java.util.Map;

public class Type extends ASTNode
{
	public boolean isInt()
	{
		return false;
	}
	public boolean isBool()
	{
		return false;
	}
	public boolean isDouble()
	{
		return false;
	}
	
	public boolean canAssign(Type t)
	{
		return false;
	}
	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		//virheilmoitus
	}
}
