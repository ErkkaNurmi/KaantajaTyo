package AST;

public class Equals extends Condition
{
	
}
