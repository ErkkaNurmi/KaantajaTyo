package AST;

import java.util.Map;

public class ReturnStatement extends ASTNode
{
	ASTNode e;
	
	public ReturnStatement(ASTNode _e)
	{
		e = _e;
	}
	
	@Override
	public void typeCheck(Map<String, Type> tenv)
	{
		e.typeCheck(tenv);
	}

}
