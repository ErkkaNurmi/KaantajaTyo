package AST;

import java.util.Map;

public class AssignStatement extends ASTNode
{
	String x;
	Value e;
	
	public AssignStatement(String _x, Value _e)
	{
		x = _x;
		e = _e;
	}
	
	@Override
	public
	void typeCheck(Map<String, Type> tenv)
	{
		e.typeCheck(tenv);
		
		if (!tenv.containsKey(x))
		{
			tenv.put(x, e.type);
		}
		
		if (!e.type.canAssign(tenv.get(x)))
		{
			//virheilmoitus
		}
	}

}
