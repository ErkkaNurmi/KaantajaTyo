package AST;

public class EqCon extends Condition
{
	public EqCon(Value _left, Value _right)
	{
		left = _left;
		right = _right;
	}
}
