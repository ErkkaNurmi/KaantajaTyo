package AST;

public class LesCon extends Condition
{
	public LesCon(Value _left, Value _right)
	{
		left = _left;
		right = _right;
	}
}
