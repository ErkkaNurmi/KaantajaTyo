package AST;

public class GreatCon extends Condition
{
	public GreatCon(Value _left, Value _right)
	{
		left = _left;
		right = _right;
	}
}
